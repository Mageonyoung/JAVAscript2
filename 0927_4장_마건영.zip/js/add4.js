//익명함수
//변수에 할당하여 사용. 하나의 값처럼 사용가능
let sum = function(a,b){
    return a+b;
}

console.log('함수 실행 결과 : ${sum(10, 20)}');
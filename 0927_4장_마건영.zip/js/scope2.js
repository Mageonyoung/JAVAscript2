var hi = "hello";//전역변수

function greeting(){
    console.log(hi); //hi의 내용이 출력되나?
}
greeting();//함수호출
(function(a,b){
    let sum = a+b;
    console.log('함수실행결과 : ${sum}')
})(100,200);
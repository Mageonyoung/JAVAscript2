function sum (num1, num2){
    var result = num1 + num2;//지역변수
}
sum(10,20);
console.log(result);
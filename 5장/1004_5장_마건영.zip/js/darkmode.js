const button = document.querySelector("#toggle-box button");
// const button = docment.querySelector("button"); 1번2번줄 둘중에 아무거나 해도 상관없음
button.onclick = () =>{ //버튼을 누르면
    document.body.classList.toggle("dark");//문서 바디에 dark스타일 적용
}
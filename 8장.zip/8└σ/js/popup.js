//브라우저 열면 팝업열기
//팝업창을 오픈
window.open("notice.html","이벤트 팝업","width=400 height=300");

//버튼을 클릭하면 팝업열기
//버튼요소가져오기
const btn = document.querySelector("button")
//버튼누르면
addEventListener("click",()=>{
    "notice.html","이벤트 팝업","width=400 height=300 left=300 top=300"});
